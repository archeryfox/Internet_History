﻿=== Original Windows 95/98 Cursor Set ===

By: darix555

Download: http://www.rw-designer.com/cursor-set/win-95-98

Author's description:

Original Win 95/98 cursors hope you like it! I replaced the working in backgroud (wib) hourglass with a cd because it looks more better and cute :-)

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.